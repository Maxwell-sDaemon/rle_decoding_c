Max heap implementation.
