maxheap
=======

Implementation of a max heap in C

Supports all the usual max-heap functions: makeHeap, buildHeap, extractMax, insert, increaseKey, etc.
